from flask import Flask, render_template, request, redirect, session, flash
app = Flask( __name__ )
app.secret_key = 'opensesame'

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/users', methods=['POST'])
def users():
    if len(request.form['name']) < 1:
        flash("This field is required")
        return redirect('/')
    if len(request.form['email']) < 1:
        flash("This field is required")
        return redirect('/')
    if len(request.form['comment']) < 1:
        flash("This field is required")
        return redirect('/')
    else:
        print 'submission successful'
        session ['name'] = request.form['name']
        session ['email'] = request.form['email']
        session ['comment'] = request.form['comment']
        return redirect('/result')

@app.route('/result')
def result():
    return render_template('/result.html',name=session['name'],email=session['email'],comment=session['comment'])

app.run(debug=True)
